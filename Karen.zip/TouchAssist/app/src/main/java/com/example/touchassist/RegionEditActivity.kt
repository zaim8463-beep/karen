package com.example.touchassist

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.*

class RegionEditActivity: Activity(){
 companion object { @Volatile var pending: TouchRegion?=null }
 private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
 override fun onCreate(savedInstanceState:Bundle?){ super.onCreate(savedInstanceState); window.decorView.layoutDirection=View.LAYOUT_DIRECTION_RTL
  val id=intent.getStringExtra("id"); val fresh=id==null; val r=if(id==null) pending else Store.loadRegions(this).firstOrNull{it.id==id}; if(r==null){finish();return}
  if(fresh){ nameDialog(r); return }
  build(r,false)
 }
 private fun nameDialog(r:TouchRegion){ val e=EditText(this); e.hint="اسم تحديد المنطقة"; AlertDialog.Builder(this).setTitle("تحديد منطقة جديد").setView(e).setNegativeButton("إلغاء"){_,_->pending=null;finish()}.setPositiveButton("حفظ"){_,_->r.name=e.text.toString().trim().ifEmpty{"منطقة ${Store.loadRegions(this).size+1}"};Store.upsertRegion(this,r);pending=null;build(r,true)}.setCancelable(false).show() }
 private fun build(r:TouchRegion,isNew:Boolean){
  val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(14),dp(18),dp(12))}
  fun label(t:String){root.addView(TextView(this).apply{text=t;textSize=14f;setPadding(0,dp(10),0,dp(3))})}
  fun field(v:String,decimal:Boolean=false):EditText { val e=EditText(this);e.setSingleLine(true);e.inputType=InputType.TYPE_CLASS_NUMBER or if(decimal) InputType.TYPE_NUMBER_FLAG_DECIMAL else 0;e.setText(v);root.addView(e,LinearLayout.LayoutParams(-1,-2));return e }
  label("اسم المنطقة");val name=EditText(this).apply{setSingleLine(true);setText(r.name)};root.addView(name)
  label("طريقة التفعيل")
  val mode=RadioGroup(this); val ball=RadioButton(this).apply{text="بالكورة (نفس نظام كور الإيماءة)";id=1}; val direct=RadioButton(this).apply{text="بدون كورة (المنطقة مباشرة)";id=2};mode.addView(ball);mode.addView(direct);mode.check(if(r.mode=="direct")2 else 1);root.addView(mode)
  label("مدد المنطقة (مللي ثانية: 0 إلى 1000)");label("مدة اللمس");val touch=field(r.touchMs.toString());label("سرعة اللمس (بكسل/ثانية)");val touchSpeed=field(r.touchSpeed.toString(),true)
  label("مدة السحب");val swipe=field(r.swipeMs.toString());label("سرعة السحب (بكسل/ثانية)");val swipeSpeed=field(r.swipeSpeed.toString(),true)
  label("مدة النقر");val tap=field(r.tapMs.toString());label("مدة النقر مع الاستمرار");val hold=field(r.holdMs.toString())
  label("الأهداف: نفس فكرة أهداف الكورة في الإيماءة")
  val actions=HashMap(r.ballActions); val rows=listOf("main" to "الهدف الرئيسي","tap" to "عند النقر","double" to "عند النقر مرتين","long" to "عند الضغط المطوّل","swipe" to "عند السحب","up" to "السحب لأعلى","down" to "السحب لأسفل","left" to "السحب لليسار","right" to "السحب لليمين")
  for((key,title) in rows){val row=TextView(this).apply{text="$title    ${Actions.label(this@RegionEditActivity,actions[key]?:"none")}";setPadding(0,dp(9),0,dp(9))};row.setOnClickListener{ActionPicker.show(this,title,true,actions[key]?:"none"){v->actions[key]=v;row.text="$title    ${Actions.label(this,v)}"}};root.addView(row)}
  val buttons=LinearLayout(this); val save=Button(this).apply{text="حفظ";setOnClickListener{
    r.name=name.text.toString().trim().ifEmpty{"منطقة"};r.mode=if(mode.checkedRadioButtonId==2)"direct" else "ball"
    r.touchMs=(touch.text.toString().toIntOrNull()?:100).coerceIn(0,1000);r.touchSpeed=(touchSpeed.text.toString().toFloatOrNull()?:800f).coerceAtLeast(1f)
    r.swipeMs=(swipe.text.toString().toIntOrNull()?:300).coerceIn(0,1000);r.swipeSpeed=(swipeSpeed.text.toString().toFloatOrNull()?:1200f).coerceAtLeast(1f)
    r.tapMs=(tap.text.toString().toIntOrNull()?:80).coerceIn(0,1000);r.holdMs=(hold.text.toString().toIntOrNull()?:500).coerceIn(0,1000)
    r.ballActions.clear();for((k,v) in actions)if(v!="none")r.ballActions[k]=v;Store.upsertRegion(this@RegionEditActivity,r);Toast.makeText(this@RegionEditActivity,"تم حفظ المنطقة",Toast.LENGTH_SHORT).show();finish()
  }};buttons.addView(save)
  val cancel=Button(this).apply{text="إلغاء";setOnClickListener{finish()}};buttons.addView(cancel)
  if(!isNew) buttons.addView(Button(this).apply{text="حذف";setOnClickListener{AlertDialog.Builder(this@RegionEditActivity).setMessage("حذف المنطقة؟").setPositiveButton("حذف"){_,_->Store.deleteRegion(this@RegionEditActivity,r.id);finish()}.setNegativeButton("إلغاء",null).show()}})
  root.addView(buttons);setContentView(ScrollView(this).apply{addView(root)})
 }
}
